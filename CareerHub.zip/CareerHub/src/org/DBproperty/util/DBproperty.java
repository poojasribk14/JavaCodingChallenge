package org.DBproperty.util;

import java.io.FileInputStream;
import java.util.Properties;

public class DBproperty {
    public static String getConnectionString(String propertyFile) {
        Properties props = new Properties();
        String connectionString = "";

        try {
            props.load(new FileInputStream(propertyFile));
            connectionString = "jdbc:mysql://" + props.getProperty("host") + ":" +
                               props.getProperty("port") + "/" + props.getProperty("database") +
                               "?user=" + props.getProperty("user") +
                               "&password=" + props.getProperty("password");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return connectionString;
    }
}
