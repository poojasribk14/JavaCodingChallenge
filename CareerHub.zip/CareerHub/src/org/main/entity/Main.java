package org.main.entity;
import org.careerhub.dao.*;

import java.util.List;
import org.careerhub.entity.*;

public class Main {
    public static void main(String[] args) {
        JobListingDaoImplementation jobDAO = new JobListingDaoImplementation();

       
       JobListingClass job = new JobListingClass(1, 101, "Software Engineer", "Develop and maintain software", "Bangalore", 100000, "Full-time", new java.util.Date(), "TechCorp");
        jobDAO.addJobListing(job);

  
        List<JobListingClass> jobList = jobDAO.getAllJobListings();
        for (JobListingClass j : jobList) {
            System.out.println("Job Title: " + j.getJobTitle() + ", Company: " + j.getCompanyName());
        }

        // Update 
        job.setSalary(110000);
        jobDAO.updateJobListing(job);

        // Delete 
        jobDAO.deleteJobListing(1);
    }
}
