 package org.careerhub.dao;

import org.careerhub.entity.JobListingClass;
import org.DBproperty.util.DBproperty;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JobListingDaoImplementation implements JobListingDAO {

    private Connection getConnection() throws SQLException {
        String url = DBproperty.getConnectionString("db.properties");
        return DriverManager.getConnection(url);
    }

  
    public void addJobListing(JobListingClass job) {
        String query = "INSERT INTO job_listings (jobID, companyID, jobTitle, jobDescription, jobLocation, salary, jobType, postedDate, companyName) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = getConnection(); PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, job.getJobID());
            ps.setInt(2, job.getCompanyID());
            ps.setString(3, job.getJobTitle());
            ps.setString(4, job.getJobDescription());
            ps.setString(5, job.getJobLocation());
            ps.setDouble(6, job.getSalary());
            ps.setString(7, job.getJobType());
            ps.setDate(8, new java.sql.Date(job.getPostedDate().getTime()));
            ps.setString(9, job.getCompanyName());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public List<JobListingClass> getAllJobListings() {
        List<JobListingClass> jobList = new ArrayList<>();
        String query = "SELECT * FROM job_listings";

        try (Connection connection = getConnection(); Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                JobListingClass job = new JobListingClass(
                        rs.getInt("jobID"),
                        rs.getInt("companyID"),
                        rs.getString("jobTitle"),
                        rs.getString("jobDescription"),
                        rs.getString("jobLocation"),
                        rs.getDouble("salary"),
                        rs.getString("jobType"),
                        rs.getDate("postedDate"),
                        rs.getString("companyName")
                );
                jobList.add(job);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return jobList;
    }

     
    public JobListingClass getJobById(int jobId) {
        JobListingClass job = null;
        String query = "SELECT * FROM job_listings WHERE jobID = ?";

        try (Connection connection = getConnection(); PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, jobId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    job = new JobListingClass(
                            rs.getInt("jobID"),
                            rs.getInt("companyID"),
                            rs.getString("jobTitle"),
                            rs.getString("jobDescription"),
                            rs.getString("jobLocation"),
                            rs.getDouble("salary"),
                            rs.getString("jobType"),
                            rs.getDate("postedDate"),
                            rs.getString("companyName")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return job;
    }

  
    public void updateJobListing(JobListingClass job) {
        String query = "UPDATE job_listings SET jobTitle = ?, jobDescription = ?, jobLocation = ?, salary = ?, jobType = ?, companyName = ? WHERE jobID = ?";
        try (Connection connection = getConnection(); PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, job.getJobTitle());
            ps.setString(2, job.getJobDescription());
            ps.setString(3, job.getJobLocation());
            ps.setDouble(4, job.getSalary());
            ps.setString(5, job.getJobType());
            ps.setString(6, job.getCompanyName());
            ps.setInt(7, job.getJobID());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public void deleteJobListing(int jobId) {
        String query = "DELETE FROM job_listings WHERE jobID = ?";
        try (Connection connection = getConnection(); PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, jobId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

