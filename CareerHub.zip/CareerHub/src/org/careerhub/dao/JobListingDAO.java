package org.careerhub.dao;

import org.careerhub.entity.JobListingClass;
 

import java.util.List;

public interface JobListingDAO {
    void addJobListing(JobListingClass job);
    List<JobListingClass> getAllJobListings();
    JobListingClass getJobById(int jobId);
    void updateJobListing(JobListingClass job);
    void deleteJobListing(int jobId);
}
