package exception;

public class InvalidJobListingException extends Exception {
    public InvalidJobListingException(String message) {
        super(message);
    }
}
