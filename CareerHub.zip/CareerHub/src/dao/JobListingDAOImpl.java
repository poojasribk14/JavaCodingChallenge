package dao;

import entity.JobListing;
import exception.DatabaseConnectionException;
import java.util.List;
import java.util.ArrayList;

public class JobListingDAOImpl implements JobListingDAO {
    private static List<JobListing> jobListings = new ArrayList<>();

    @Override
    public void insertJobListing(JobListing jobListing) throws DatabaseConnectionException {
        // Simulate inserting to a database
        jobListings.add(jobListing);
        System.out.println("Job Listing Inserted into Database.");
    }

    @Override
    public List<JobListing> getAllJobListings() throws DatabaseConnectionException {
        return jobListings;  // Return the list of job listings (this can be modified to fetch from a database)
    }
}
